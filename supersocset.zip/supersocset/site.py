import json

with open('static/direct.json', 'w') as Wall:
    json.dump({}, Wall)