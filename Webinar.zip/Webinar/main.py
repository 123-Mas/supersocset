from flask import Flask, render_template, request
from argparse import ArgumentParser

app = Flask(__name__)


@app.route('/')
@app.route('/<name>')
def index(name=None):
    if name is None:
        name = 'world'
    # return f'<h1>Hello, {name}</h1>'
    return render_template('index.html',
                           name=name,
                           title="Index-page",
                           items=[
                               'картина',
                               'корзина',
                               'картонка'
                           ]
                           )


@app.route('/hello/<name>', methods=['GET', 'POST'])
def hello(name=None):
    return render_template('hello.html',
                           title=f"Hello {name}",
                           name=name
                           )


@app.route('/hello/', methods=['GET', 'POST'])
def verbose_hello():
    if request.method == 'GET':
        return render_template(
            'hello_form.html',
            title='Say your name'
        )
    else:
        name = request.form['name']
        return render_template(
            'hello.html',
            title=f'Hello, {name}',
            name=name
        )

if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--host', type=str, default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8080)
    parser.add_argument('--debug', '-d', action='store_true', default=False)
    args = parser.parse_args()

    app.run(args.host, args.port, debug=args.debug)

    # app.run('127.0.0.1', 8080, debug=True)